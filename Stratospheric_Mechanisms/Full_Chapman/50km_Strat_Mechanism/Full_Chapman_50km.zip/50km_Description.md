The Full Chapman Mechanism is listed in this file as a zip file at 50km (50629.41m). Download the zip file to your computer and upload it to MusicBox to run the mechanism. To simplify the mechanism, the initial concentrations once uploaded to MusicBox should be changed. For the full mechanism, leave as is and run. For simplifications, see below:

Ox: Set all variables with H, CH3, CH4, CH2O, CO and CO2 to zero

Ox and HOx: Set all variables with N (Except for N2), Cl, Br, H2402, CFC, HCFC to zero

Ox, HOx and NOx: Set all variables with Cl, Br, H2402, CFC, HCFC to zero

Ox, HOx, NOx and ClOx: Set all variables with Br to zero

Full Mechanism: No Changes


